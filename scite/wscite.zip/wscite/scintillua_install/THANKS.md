# Thanks

Thank you everyone for your contributions and feedback. They have helped make
Scintillua better and better over the years.

## Code Contributors

* Alejandro Baez
* Alex Saraci
* Brian Schott
* Carl Sturtivant
* Chris Emerson
* Christian Hesse
* David B. Lamkins
* Heck Fy
* Jason Schindler
* Jeff Stone
* Joshua Krämer
* Klaus Borges
* Larry Hynes
* M Rawash
* Marc André Tanner
* Markus F.X.J. Oberhumer
* Martin Morawetz
* Michael Forney
* Michael T. Richter
* Michel Martens
* Murray Calavera
* Neil Hodgson
* Olivier Guibé
* Peter Odding
* Piotr Orzechowski
* Richard Philips
* Robert Gieseke
* Roberto Ierusalimschy
* S. Gilles
* Stéphane Rivière
* Tymur Gubayev
* Wolfgang Seeberg

If I have left off your name, please [contact me][]. I am very sorry about that.

[contact me]: README.html#Contact
